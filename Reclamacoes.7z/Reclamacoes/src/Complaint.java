/* Candidata : Rosane Caldeira
 * Depoimento: O estudo de caso proposto se assemelha ao da literatura de Katy e Bates
sobre um simulador dos comportamentos grasnar, andar, voar de um Duck, através do SimuDuck() 
 * onde Duck era a classse abstata os comportamentos implementados via herança e exibidos via interface
 estudei e fiz exercícios com conexão de dados e implementações mas devido a restrições de hardware foi o melhor que deu
obrigada! 
*/
public abstract class Complaint {
 AnimalBehavior animalBehavior;
 FoodBehavior foodBehavior;
  public Complaint() {
 }
 public void formQueixaDiversos(){
 queixaDiversos.quack();
 }
 public void setQueixaAnimal(Reclamacoes qa){
 animalBehavior = qa;
 }
 public void setQueixaFood(QuackBehavior qf) {
 foodBehavior = qf;
 }
}