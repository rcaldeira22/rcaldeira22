/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 3119150
 */
public class AnimalComplaint extends Complaint {
     public AnimalComplaint(){
        comportBehavior = new AnimalBehavior();
        comportBehavior = new FoodBehavior();
    }
    public void display(){
        System.out.println("Este é o AnimalComplaint");
    }
}
    
}
